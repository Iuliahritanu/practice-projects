# descriere cerinte proiect

### Cerinte

- cand utilizatorul acceseaza pagina trebuie sa vada un calculator(creare interfata html)
- utilizatorul poate sa selecteze primul numar (primul numar este reprezentat de selectia cumulativa a tuturor numerelor pana cand apasa pe un operator cu exceptia punctului)
- dupa apasarea primului numar selectam un operator(inmultire, impartire, etc)
- utilizatorul mai poate selecta un numar pentru a face operatia
- totodata se mai pot selecta alte numere si operatori
- displayul calculatorului trebuie sa ne arate ordinea operatiilor si rezultatul va fi aratat dupa ce apasam egal

### Cerinte tehnice

1. Crearea interfetei html
2. Crearea logica pentru a pastra istoricul utilizatorului si pentru a depista fiecare numar si operator in parte
3. Cand apasam egal se executa toate calculele matematice
4. In display se afiseaza toti pasii de mai sus
5. Daca avem un operator selectat si apasam un alt operator il suprascriem pe cel anterior
6. Butonul backspace sterge cate o cifra pe rand din numarul curent care este mai mare decat zero
7. CE sterge tot numarul nu doar o cifra
8. C-ul reseteaza calculatorul
